# FRLG → Gen1 semantic lookup

Layout extraction via metatile **behaviors**, not tile art.

## Terrain → Gen1 blocks

| Category | Gen1 block | Notes |
|----------|------------|-------|
| `WATER` | **67** | MB_OCEAN_WATER / pond / deep → Gen1 67 (Route 21 / Cinnabar) |
| `TALL_GRASS` | **11** | MB_TALL_GRASS 0x02 → Gen1 11 |
| `SHORT_GRASS` | **1** | MB_NORMAL walkable on routes → Gen1 1 |
| `TOWN_PATH` | **1** | MB_NORMAL walkable in towns → Gen1 1 grass (Pallet/Pewter plaza) |
| `SAND` | **10** | MB_SAND 0x21 → Gen1 10 dirt |
| `PATH` | **7** | carved corridors → Gen1 7 |
| `PIER` | **7** | FRLG wooden pier mids over ocean → Gen1 7 path |
| `TREE` | **15** | General/Sevii tree mids (NOT secondary BUILDING catch-all) → Gen1 15 |
| `CLIFF` | **44** | cliff mids / solid outdoor rock → Gen1 44; dress_cliffs adds FACE/CLIFF_W |
| `COAST_CLIFF` | **100** | cliff touching ocean → Gen1 100 (Cinnabar west) |
| `LEDGE` | **55** | MB_JUMP_{E,W,N,S} → Gen1 13/39/26/55 by direction (not flattened) |
| `STAIR` | **47** | MB_ROCK_STAIRS 0x2A → Gen1 47 |
| `ROCK_DECK` | **123** | MB_MOUNTAIN_TOP 0x0C → Gen1 123 (Cinnabar/Route 10 walkable rock) |
| `BLOCKED` | **44** | other impassable → mountain mass |

## Structural (not baked into the tile grid)

These become `(x, y, category)` markers. Grid cells get a walkable fill until the stamp pass places real buildings/doors/caves.

| Category | Fill under marker | Notes |
|----------|-------------------|-------|
| `BUILDING` | `SHORT_GRASS` → 1 | STRUCTURAL — roofs/walls; trees excluded via TREE_MIDS |
| `CAVE` | `PATH` → 7 | STRUCTURAL — not a tile; (x,y) list + PATH fill until cave stamp |
| `DOOR` | `PATH` → 7 | STRUCTURAL — not a tile; (x,y) list + PATH fill until stamp |
| `SIGN` | `PATH` → 7 | STRUCTURAL — not a tile; (x,y) list + PATH fill |

## Ledge direction

FRLG encodes jump direction as distinct behaviors (`MB_JUMP_EAST=0x38` … `MB_JUMP_SOUTH=0x3B`). That direction is carried as a second field — not flattened.

| Dir | FRLG | Gen1 ledgeTile |
|-----|------|----------------|
| S | `0x3B` | **55** |
| W | `0x39` | **39** |
| E | `0x38` | **13** |
| N | `0x3A` | **26** (visual only; Gen1 has no north hop) |

## Building stamps (Gen1)

Footprint-only (no bounding-box clear — preserves adjacent PATH/GRASS).
`has_back_door` on a def adds a north-face door + second warp (Celadon-style).

- **pc** 2×2 warp_face=`door` has_back_door=False dest=`SEVII_ONE_ISLAND_POKECENTER`
- **mart** 2×2 warp_face=`door` has_back_door=False dest=`SEVII_ONE_ISLAND_MART`
- **house** 3×2 warp_face=`door` has_back_door=False dest=`None`
- **harbor** 3×2 warp_face=`threshold` has_back_door=False dest=`SEVII_ONE_ISLAND_HARBOR`

House exteriors stamp now; interiors (`SEVII_ONE_ISLAND_HOUSE1/2`) not registered in maps.lua yet — no front warps until those maps exist.
